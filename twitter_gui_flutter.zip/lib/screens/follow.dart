import 'package:flutter/material.dart';

class Follow extends StatelessWidget {
  const Follow({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

class Timeline extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: 1,
        itemBuilder: (context, index) {
          return Tweet();
        });
  }
}

class Tweet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      //memo1
      margin: EdgeInsets.all(8.0),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              CircleAvatar(
                //프로필 이미지
                backgroundImage: AssetImage('assets/images/aba4647.png'),
                backgroundColor: Colors.indigo,
                radius: 24.0,
              ),
              SizedBox(width: 8.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    //유저 이름, 계정
                    Text(''),
                    SizedBox(height: 8),
                    GestureDetector(
                      onTap: () {},
                      child: Text('@aba4647'),
                    ),
                  ]),
                  //게시물 업로드 시간
                ],
              ),
            ],
          ),
          SizedBox(height: 18.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.comment, size: 18),
                onPressed: () {
                  //Comment 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.repeat, size: 18),
                onPressed: () {
                  //Repeat버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.thumb_up, size: 18),
                onPressed: () {
                  //좋아요 버튼 function
                  //아이콘을 누르면 1.좋아요 +1 , 2.아이콘 색 채워짐
                },
              ),
              IconButton(
                icon: Icon(Icons.insert_chart, size: 18),
                onPressed: () {
                  //조회수 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.turned_in_not, size: 18),
                onPressed: () {
                  //북마크 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.account_circle_outlined, size: 18),
                onPressed: () {},
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
