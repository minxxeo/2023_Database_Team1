import 'package:flutter/material.dart';
import 'package:flutter_application_1/db_assoc/follow_list.dart';
import 'package:flutter_application_1/post/post.dart';
import 'package:flutter_application_1/screens/profile.dart';
import 'package:get/get.dart';

class sc extends StatelessWidget {
  //const sc({super.key});

  List<Widget> boxes = [];
  //String id = Get.arguments;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Twitter'),
        centerTitle: true,
        backgroundColor: Colors.blue,
        elevation: 0.0,
      ),
      body: Post(),
      //Timeline(),
      //draw 메뉴
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage('assets/images/pikra10.png'),
              ),
              accountName: Text(''),
              //Connect with server -> User's Email
              accountEmail: Text('users id'),
              //onDetailsPressed: () {},
              decoration: BoxDecoration(color: Colors.lightBlue),
            ),
            ListTile(
              leading: Icon(Icons.account_circle_outlined),
              iconColor: Colors.black,
              focusColor: Colors.purple,
              title: Text('Profile'),
              onTap: () {
                Get.to(() => UserProfileScreen(), arguments: 'qwe12345');
              },
              trailing: Icon(Icons.navigate_next),
            ),
            ListTile(
              leading: Icon(Icons.bookmark_outline),
              iconColor: Colors.black,
              focusColor: Colors.purple,
              title: Text('Follow'),
              onTap: () {
                Get.to(() => FollowList());
              },
              trailing: Icon(Icons.navigate_next),
            ),
            ListTile(
              leading: Icon(Icons.notifications_none),
              iconColor: Colors.black,
              focusColor: Colors.purple,
              title: Text('notions'),
              onTap: () {},
              trailing: Icon(Icons.navigate_next),
            ),
            ListTile(
              leading: Icon(Icons.logout_outlined),
              iconColor: Colors.black,
              focusColor: Colors.purple,
              title: Text('sign out'),
              onTap: () {},
              //trailing: Icon(Icons.navigate_next),
            ),
          ],
        ),
      ),
      /*
      floatingActionButton: ExpandableFab(
        distance: 100.0,
        children: [
          ActionButton(
            onPressed: () {},
            icon: Icon(Icons.edit),
          ),
          ActionButton(
            onPressed: () {},
            icon: Icon(Icons.bookmark),
          ),
          ActionButton(onPressed: () {}, icon: Icon(Icons.notifications_none)),
          ActionButton(onPressed: () {}, icon: Icon(Icons.logout_outlined)),
        ],
      ),*/
    );
  }
}

class Timeline extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: 1,
        itemBuilder: (context, index) {
          return Tweet();
        });
  }
}

class Tweet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      //memo1
      margin: EdgeInsets.all(8.0),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              CircleAvatar(
                //프로필 이미지
                //backgroundImage: AssetImage(Connect with server -> User's profile image),
                backgroundColor: Colors.indigo,
                radius: 24.0,
              ),
              SizedBox(width: 8.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    //유저 이름, 계정
                    Text(' '),
                    SizedBox(height: 8),
                    GestureDetector(
                      onTap: () {
                        Get.to(() => UserProfileScreen());
                      },
                      //child: Text(Connect with server -> User's email),
                    ),
                  ]),
                  //게시물 업로드 시간
                  //Text(CurrentTime),
                ],
              ),
            ],
          ),
          SizedBox(height: 18.0),
          Text('Contents'),
          SizedBox(height: 18.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.comment, size: 18),
                onPressed: () {
                  //Comment 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.repeat, size: 18),
                onPressed: () {
                  //Repeat버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.thumb_up, size: 18),
                onPressed: () {
                  //좋아요 버튼 function
                  //아이콘을 누르면 1.좋아요 +1 , 2.아이콘 색 채워짐
                },
              ),
              IconButton(
                icon: Icon(Icons.insert_chart, size: 18),
                onPressed: () {
                  //조회수 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.turned_in_not, size: 18),
                onPressed: () {
                  //북마크 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.account_circle_outlined, size: 18),
                onPressed: () {},
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
