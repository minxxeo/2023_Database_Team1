import 'package:flutter/material.dart';

class FollowList extends StatelessWidget {
  const FollowList({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        //body: Connect with server -> follow list function(),
        );
  }
}

class Tweet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      //memo1
      margin: EdgeInsets.all(8.0),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  //프로필 이미지
                  backgroundImage: AssetImage('assets/images/aba4647.png'),
                  backgroundColor: Colors.indigo,
                  radius: 24.0,
                ),
                SizedBox(width: 8.0),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //유저 이름, 계정
                          Text(' '),
                          SizedBox(height: 8),
                          GestureDetector(
                            onTap: () {},
                            child: Text('@aba4647'),
                          ),
                        ]),
                    //게시물 업로드 시간
                    Text('1시간 전'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 10.0),
          ],
        ),
      ),
    );
  }
}
