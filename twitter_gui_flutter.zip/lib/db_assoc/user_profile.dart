import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

void main() {
  runApp(UserProfile());
}

class UserProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ChangeScreen(),
    );
  }
}

class ChangeScreen extends StatelessWidget {
  final TextEditingController newPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Follow'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  //backgroundImage: AssetImage(Connect with server -> User's profile image route),
                  backgroundColor: Colors.indigo,
                  radius: 100.0,
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    //Connect with server -> follow function
                    Fluttertoast.showToast(msg: 'Follow success');
                  },
                  child: Text('Follow'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
