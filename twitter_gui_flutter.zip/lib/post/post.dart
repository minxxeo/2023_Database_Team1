import 'package:flutter/material.dart';
import 'package:flutter_application_1/db_assoc/user_profile.dart';
import 'package:flutter_application_1/post/comment.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(Post());
}

final String id = Get.arguments;

class Post extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController tweetController = TextEditingController();
  List<Widget> tweets = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: tweetController,
                  decoration: InputDecoration(
                    hintText: '트윗을 작성하세요',
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    tweets.add(Tweet(
                      content: tweetController.text,
                      onDelete: () {
                        // Tweet 삭제 함수
                        setState(() {
                          tweets.removeLast();
                        });
                      },
                    ));
                    tweetController.clear();
                  });
                },
                child: Text('Tweet'),
              ),
            ],
          ),
          // 저장된 Tweet 위젯들을 표시
          Column(
            children: tweets,
          ),
        ],
      ),
    );
  }
}

class Tweet extends StatelessWidget {
  final String content;
  final VoidCallback onDelete;

  Tweet({required this.content, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    // 현재 시간을 받아오기 위해 intl 패키지 사용
    var now = DateTime.now();
    var formattedDate = DateFormat.yMMMd().add_Hm().format(now);

    return Card(
      margin: EdgeInsets.all(8.0),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              CircleAvatar(
                backgroundImage: AssetImage('assets/images/aba4647.png'),
                backgroundColor: Colors.indigo,
                radius: 24.0,
              ),
              SizedBox(width: 8.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(' '),
                    SizedBox(height: 8),
                    GestureDetector(
                      onTap: () {
                        // UserProfileScreen으로 이동하는 코드
                        // Get.to(() => UserProfileScreen());
                      },
                      //주석 없애기
                      child: Text('@aba4647'),
                    ),
                  ]),
                  // 현재 시간 표시
                  Text(formattedDate),
                ],
              ),
            ],
          ),
          SizedBox(height: 18.0),
          // 트윗 내용 표시
          Text(content),
          SizedBox(height: 18.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.comment, size: 18),
                onPressed: () {
                  // Comment 버튼 function
                  Get.to(() => CommentSection());
                },
              ),
              IconButton(
                icon: Icon(Icons.repeat, size: 18),
                onPressed: () {
                  // Repeat 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.thumb_up, size: 18),
                onPressed: () {
                  // 좋아요 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.insert_chart, size: 18),
                onPressed: () {
                  // 조회수 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.turned_in_not, size: 18),
                onPressed: () {
                  // 북마크 버튼 function
                  Get.to(() => UserProfile());
                },
              ),
              IconButton(
                icon: Icon(Icons.account_circle_outlined, size: 18),
                onPressed: () {
                  // 추가적인 버튼 function
                },
              ),
              IconButton(
                icon: Icon(Icons.delete, size: 18),
                onPressed: () {
                  // Tweet 삭제 버튼
                  onDelete();
                },
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
