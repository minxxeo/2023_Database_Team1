import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CommentSection extends StatefulWidget {
  @override
  _CommentSectionState createState() => _CommentSectionState();
}

class _CommentSectionState extends State<CommentSection> {
  final TextEditingController _commentController = TextEditingController();
  final List<String> _comments = [];

  void _addComment(String newComment) {
    setState(() {
      _comments.add(newComment);
    });
  }

  void _navigateToCommentScreen() async {
    String newComment = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CommentScreen()),
    );

    if (newComment != null && newComment.isNotEmpty) {
      _addComment(newComment); // 댓글 추가
    } else {
      Fluttertoast.showToast(msg: 'Please enter something');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  // 특정 버튼을 누를 때 댓글 작성 화면으로 이동
                  _navigateToCommentScreen();
                },
                child: Text('댓글 작성하기'),
              ),
              SizedBox(height: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ..._comments.map((comment) => CommentBox(comment: comment)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class CommentBox extends StatelessWidget {
  final String comment;

  CommentBox({required this.comment});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8),
      margin: EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(comment),
    );
  }
}

class CommentScreen extends StatefulWidget {
  @override
  _CommentScreenState createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  final TextEditingController _commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('댓글 작성'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _commentController,
              decoration: InputDecoration(labelText: '댓글을 입력하세요'),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                // 등록 버튼을 누를 때 작성한 댓글을 호출한 화면으로 전달
                Navigator.pop(context, _commentController.text);
              },
              child: Text('댓글 등록'),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text('댓글 섹션 예제'),
      ),
      body: CommentSection(),
    ),
  ));
}
