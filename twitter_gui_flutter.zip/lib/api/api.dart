class API {
  static const hostConnect = "http://192.168.0.9/sign_up";
  static const hostConnectUser = "$hostConnect/user";

  static const signup = "$hostConnect/user/signup.php";
  static const login = "$hostConnect/user/login.php";
  static const validateId = "$hostConnect/user/validate_id.php";
}
