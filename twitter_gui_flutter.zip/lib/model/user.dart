class User {
  int user_id;
  String user_name;
  String user_account;
  String user_password;

  User(this.user_id, this.user_name, this.user_account, this.user_password);

  factory User.fromJson(Map<String, dynamic> json) => User(
        int.parse(json['user_id']),
        json['user_name'],
        json['user_account'],
        json['user_password'],
      );

  Map<String, dynamic> toJson() => {
        'user_id': user_id.toString(),
        'user_name': user_name,
        'user_account': user_account,
        'user_password': user_password
      };
}
